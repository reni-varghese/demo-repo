import 'bootstrap/dist/css/bootstrap.min.css';
import {createBrowserRouter,RouterProvider} from 'react-router-dom'
import AddEmployee from './components/AddEmployee';
import EmployeeList from './components/EmployeeList';
import './components/styles.css';

const router=createBrowserRouter([
  {path:"/",element:<EmployeeList/>},
  {path:"/add",element:<AddEmployee/>}
])

function App() {
  return (
    <RouterProvider router={router}/>
  );
}

export default App;
