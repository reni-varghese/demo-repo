import axios from "axios";
import { useState } from "react";
const AddEmployee=()=>{

    const [_id,set_Id]=useState('');
    const [name,setName]=useState('');
    const [photo,setPhoto]=useState('')


    const onIdChange=(e)=>{
        set_Id(e.target.value);
    }
    const onNameChange=(e)=>{
        setName(e.target.value);
    }
    const onPhotoChange=async (e)=>{
        console.log(e.target.files[0]);
        const file=e.target.files[0];
        const base64File=await convertToBase64(file);
        setPhoto(base64File);

    }

    const onAddEmployee=async (e)=>{
        e.preventDefault();
        const employee={
            _id,
            name,
            photo
        }
        console.log(employee);
        
        const response=await axios.post("http://localhost:5000/api/employees",employee);
        console.log(response.data)
    }

    return(
        <div className="container">
            <h3 className="text-primary">Add Employee</h3>
            <form className="col-4" onSubmit={onAddEmployee}>
                <div className="form-group">
                    <label>Employee Id</label>
                    <input type="text" name="_id" className="form-control" onChange={onIdChange}/>
                </div>
                <div className="form-group">
                    <label>Name</label>
                    <input type="text" name="name" className="form-control" onChange={onNameChange}/>
                </div>
                <div className="form-group">
                    <label>Upload Photo</label>
                    <input type="file" name="photo" className="form-control" accept=".jpeg, .png, .jpg" onChange={onPhotoChange}/>
                </div>
                <br/>
                <button className="btn btn-primary" type="submit">Add</button>
            </form>
        </div>
    )
}

function convertToBase64(file){
    return new Promise((resolve,reject)=>{
        const fileReader=new FileReader();
        fileReader.readAsDataURL(file);
        fileReader.onload=()=>{
            resolve(fileReader.result)
        }
        fileReader.onerror=(error)=>{
            reject(error);
        }
    })
}

export default AddEmployee;