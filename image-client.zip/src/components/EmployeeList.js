import {useState,useEffect} from 'react';
import axios from 'axios';
const EmployeeList=()=>{
    const [employees,setEmployees]=useState([]);
    useEffect(()=>{
        return async ()=>{
            const response=await axios.get("http://localhost:5000/api/employees");
            setEmployees(response.data);
        }
    },[])
    return(
        <div className="container">
            <h3 className="text-primary">Employee Details</h3>
            <table className='table table-striped table-bordered'>
                <thead>
                    <tr>
                        <th>Employee Id</th>
                        <th>Name</th>
                        <th>Photo</th>
                    </tr>
                </thead>
                <tbody>
                    {employees.map(emp=><tr key={emp._id}>
                        <td>{emp._id}</td>
                        <td>{emp.name}</td>
                        <td>
                            <img width={50} height={50} src={emp.photo} alt="Image Not found"/>
                        </td>
                    </tr>)}
                </tbody>
            </table>
        </div>
    )
}

export default EmployeeList;