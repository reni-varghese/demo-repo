import { useRef, useContext, useEffect,useState } from "react";
import { useNavigate,useParams } from 'react-router-dom';
import EmployeeContext from "./contexts/EmployeeContext";

const UpdateEmployee = () => {

    const [gender,SetGender]=useState('');

    const params = useParams();
    const idRef = useRef();
    const nameRef = useRef();
    const genderRef = useRef();
    const ageRef = useRef();
    const salaryRef = useRef()

    const context = useContext(EmployeeContext);

    const navigate = useNavigate()

    let flag=useRef(true);

    useEffect(() => {
        if(flag.current){
            return () => {
                flag.current=false;
                const employee=context.employees.find(e=>e.id==params.id)
                console.log(employee)
                idRef.current.value=employee.id;
                nameRef.current.value=employee.name;
                genderRef.current.value=employee.gender;
                ageRef.current.value=employee.age;
                salaryRef.current.value=employee.salary
                SetGender(employee.gender)
            }
        }
      
    },[])

    const onGenderChange=(event)=>{

    }
    
    const onUpdate = (event) => {
        event.preventDefault()
        const employee={
            id: idRef.current.value,
            name:nameRef.current.value,
            gender:genderRef.current.value,
            age:ageRef.current.value,
            salary:salaryRef.current.value

           
        }
        let newEmployees=context.employees.filter(e=>e.id!=params.id);
        newEmployees=[...newEmployees,employee];
        newEmployees.sort((e1,e2)=>e1.id-e2.id)
        context.employees=newEmployees;

        navigate("/employees")



    }

    return (
        <div>
            <h3 className="text-info">Update Employee</h3>
            <form className="col-4" onSubmit={onUpdate}>
                <div className="form-group">
                    <label>Employee Id</label>
                    <input type="text" className="form-control" ref={idRef} />
                </div>
                <div className="form-group">
                    <label>Name</label>
                    <input type="text" className="form-control" ref={nameRef} />
                </div>
                <div className="form-group">
                    <label>Gender</label>
                    &nbsp;&nbsp;
                    <div className="form-check-inline">
                        <input type="radio" className="form-check-input" name="gender" value="Male"
                            ref={genderRef}  checked={gender==='Male'} onChange={onGenderChange}/>
                        <label className="form-check-label">Male</label>
                    </div>
                    <div className="form-check-inline">
                        <input type="radio" className="form-check-input" name="gender" value="Female"

                            ref={genderRef} checked={gender==='Female'} onChange={onGenderChange}/>
                        <label className="form-check-label">Female</label>
                    </div>
                </div>
                <div className="form-group">
                    <label>Age</label>
                    <input type="text" className="form-control" ref={ageRef} />
                </div>
                <div className="form-group">
                    <label>Salary</label>
                    <input type="text" className="form-control" ref={salaryRef} />
                </div>
                <br />
                <button className="btn btn-info">Update Employee</button>
            </form>
        </div>
    )

}


export default UpdateEmployee;