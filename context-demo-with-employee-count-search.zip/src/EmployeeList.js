import { useContext, useState, useEffect, useRef } from "react";
import EmployeeContext from "./contexts/EmployeeContext";
import Employee from "./Employee";
import { useNavigate } from "react-router-dom";
import EmployeeCount from "./EmployeeCount";
import "./EmployeeList.css";
import SearchEmployee from "./SearchEmployee";

const EmployeeList = () => {
  const [all, setAll] = useState(0);
  const [male, setMale] = useState(0);
  const [female, setFemale] = useState(0);
  const [filteredEmployees, setFilteredEmployees] = useState([]);

  const context = useContext(EmployeeContext);

  const navigate = useNavigate();
  const flag = useRef(true);
  useEffect(() => {
    if (flag.current) {
      return () => {
        flag.current = false;
        setAll(context.employees.length);
        setMale(
          context.employees.filter((x) => x.gender.toLowerCase() === "male")
            .length
        );
        setFemale(
          context.employees.filter((x) => x.gender.toLowerCase() === "female")
            .length
        );
        setFilteredEmployees(context.employees);
      };
    }
  }, []);

  const onAddNew = () => {
    navigate("/add");
  };
  const selectionChange = (selectedValue) => {
    console.log("selectedValue", selectedValue);
    if (selectedValue === "All") {
      setFilteredEmployees(context.employees);
    } else {
      setFilteredEmployees(
        context.employees.filter((x) => x.gender === selectedValue)
      );
    }
  };
  const nameChangeHandler = (value) => {
    setFilteredEmployees(
      context.employees.filter((x) =>
        x.name.toLowerCase().startsWith(value.toLowerCase())
      )
    );
  };

  return (
    <div>
      <h3 className="text-primary">Employee Details</h3>
      <hr />
      <EmployeeCount
        all={all}
        male={male}
        female={female}
        selectionChange={selectionChange}
      />
      <hr />
      <SearchEmployee onNameChange={nameChangeHandler} />
      <hr />
      <button onClick={onAddNew} className="btn btn-primary">
        Add New
      </button>
      <table className="table  table-striped table-bordered">
        <thead>
          <tr>
            <th>Employee Id</th>
            <th>Name</th>
            <th>Gender</th>
            <th>Age</th>
            <th>Salary</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredEmployees.map((emp) => (
            <Employee key={emp.id} employee={emp} />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeList;
