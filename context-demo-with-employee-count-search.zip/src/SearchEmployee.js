const SearchEmployee = ({ onNameChange }) => {
  const onSearchItemChange = (event) => {
    onNameChange(event.target.value);
  };
  return (
    <div className="text-primary col-6">
      Search Employee By Name{" "}
      <input
        type="text"
        className="form-control"
        onChange={onSearchItemChange}
      />
    </div>
  );
};

export default SearchEmployee;
