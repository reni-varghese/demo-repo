import { useState } from "react";

const EmployeeCount = ({ all, male, female, selectionChange }) => {
  const [selectedButtonValue, setSelectedButtonValue] = useState("All");

  const onselectionchange = (event) => {
    setSelectedButtonValue(event.target.value);
    selectionChange(event.target.value);
  };

  return (
    <div className="text-primary form-check-inline">
      Show : &nbsp;
      <input
        className="form-check-input"
        type="radio"
        name="count"
        value="All"
        onChange={onselectionchange}
        checked={selectedButtonValue === "All"}
      />
      &nbsp; All({all}) &nbsp;
      <input
        className="form-check-input"
        type="radio"
        name="count"
        value="Male"
        onChange={onselectionchange}
        checked={selectedButtonValue === "Male"}
      />
      &nbsp; Male({male}) &nbsp; &nbsp;
      <input
        className="form-check-input"
        type="radio"
        name="count"
        value="Female"
        onChange={onselectionchange}
        checked={selectedButtonValue === "Female"}
      />
      &nbsp; Female({female})
    </div>
  );
};

export default EmployeeCount;
