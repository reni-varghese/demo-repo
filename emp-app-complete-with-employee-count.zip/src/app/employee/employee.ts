export interface Employee {
    id:number,
    name:string,
    gender:string,
    age:number,
    salary:number
}
