import { Router } from '@angular/router';
import { EmployeeService } from './../employee.service';
import { Component } from '@angular/core';
import { Employee } from '../employee';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
})
export class EmployeeListComponent {
  employees: Employee[];

  selectButtonValue: string = 'All';

  constructor(
    private employeeService: EmployeeService,
    private router: Router
  ) {}

  ngOnInit() {
    this.employees = this.employeeService.employees;
  }

  onUpdate(id: number) {
    this.router.navigate(['/update', id]);
  }

  onDelete(employee: Employee) {
    let response = confirm(`Do you wish to delete employee ${employee.name}`);
    if (response) {
      this.employeeService.deleteEmployee(employee.id);
    }
    this.employees = this.employeeService.employees;
    this.router.navigate(['/employees']);
  }

  getTotalEmployeeCount() {
    return this.employees.length;
  }

  getMaleEmployeeCount() {
    return this.employees.filter((x) => x.gender.toLowerCase() === 'male')
      .length;
  }
  getFemaleEmployeeCount() {
    return this.employees.filter((x) => x.gender.toLowerCase() === 'female')
      .length;
  }
  onGenderButtonValueChange($event: string) {
    this.selectButtonValue = $event;
  }
}
