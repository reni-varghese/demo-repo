import { Component, EventEmitter, Input, Output } from '@angular/core';
import { bufferCount } from 'rxjs';

@Component({
  selector: 'app-employee-count',
  templateUrl: './employee-count.component.html',
  styleUrls: ['./employee-count.component.css'],
})
export class EmployeeCountComponent {
  selectedRadioButtonValue: string = 'All';

  @Input()
  all: number = 5;
  @Input()
  male: number = 2;
  @Input()
  female: number = 3;

  @Output()
  countButtonValueChange: EventEmitter<string> = new EventEmitter<string>();

  onCountButtonValueChange() {
    this.countButtonValueChange.emit(this.selectedRadioButtonValue);
  }
}
