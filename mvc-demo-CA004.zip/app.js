const express=require('express');
const mongoose=require('mongoose');
const expressHbs=require('express-handlebars');
const router=require('./routes')


const app=express();
app.use(express.urlencoded({extended:false}))
app.use(express.static("public"));
const hbs=expressHbs.create({defaultLayout:'main-layout'});
app.engine("handlebars",hbs.engine);
app.set("view engine","handlebars")
app.set("views","views");

app.use(router);



mongoose.connect('mongodb://127.0.0.1/empdb')
.then(result=>{
    console.log("Connected to MongoDb");
    app.listen(5000,()=>{
        console.log("Server started @PORT 5000")
    })
})