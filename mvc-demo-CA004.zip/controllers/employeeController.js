const Employee=require('../models/Employee');

exports.getAll=async (req,res)=>{

    const employees=await Employee.find().lean();
    res.render("employees",{employees,title:'Employee Details'})

}

exports.showAddForm=(req,res)=>{
    res.render("add",{title:'Add Employee'});
}

exports.addEmployee=async (req,res)=>{
    console.log(req.body)
    const employee=new Employee({
        _id:req.body._id,
        name:req.body.name,
        gender:req.body.gender,
        age:req.body.age,
        salary:req.body.salary
    });

    const result=await employee.save()
    res.redirect("/")
}

exports.showUpdateForm=async (req,res)=>{
    const  employee=await Employee.findById(req.query.id).lean();
    res.render("update",{title:'Update Employee',employee,isMale:employee.gender==='Male',isFemale:employee.gender==='Female'});
}

exports.updateEmployee=async (req,res)=>{
    const employee=await Employee.findById(req.body._id);
    employee.name=req.body.name;
    employee.gender=req.body.gender;
    employee.age=req.body.age;
    employee.salary=req.body.salary;
    const result=await employee.save();

    res.redirect("/")
}

exports.showDelete=async (req,res)=>{

    const employee=await Employee.findById(req.query.id).lean();
    res.render("delete",{employee})


}

exports.deleteEmployee=async (req,res)=>{
    const result=await Employee.findByIdAndRemove(req.query.id);
    res.redirect("/")
}