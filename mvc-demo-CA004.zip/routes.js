const express=require('express');
const {getAll, showAddForm, addEmployee, showUpdateForm, updateEmployee, showDelete, deleteEmployee}=require('./controllers/employeeController');

const router=express.Router();


router.get("/",getAll)
router.get("/add",showAddForm);
router.post("/add-employee",addEmployee)
router.get("/update",showUpdateForm)
router.post("/update-employee",updateEmployee)
router.get("/delete",showDelete);
router.get("/delete-employee",deleteEmployee)
module.exports=router;