const mongoose=require('mongoose');

const employeeSchema=new mongoose.Schema({
    _id:Number,
    name:String,
    gender:String,
    age:Number,
    salary:Number
})

const Employee=mongoose.model('Employee',employeeSchema);

module.exports=Employee;