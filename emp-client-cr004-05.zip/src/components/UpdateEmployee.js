import { useEffect, useState } from "react";
import { updateEmployee, getById } from "../services/apiCalls";
import {useNavigate, useParams} from 'react-router-dom';

const UpdateEmployee=()=>{

    const [id,setId]=useState('');
    const [name,setName]=useState('');
    const [gender,setGender]=useState('');
    const [age,setAge]=useState('')
    const [salary,setSalary]=useState('')

    const navigate=useNavigate();

    const params=useParams();

    useEffect(()=>{
        return async ()=>{
            const employee=await getById(+params.id);
            setId(employee.id);
            setName(employee.name)
            setGender(employee.gender)
            setAge(employee.age);
            setSalary(employee.salary)
        }
    },[])

    const onIdChange=(event)=>{
        setId(event.target.value)
    }
    const onNameChange=(event)=>{
        setName(event.target.value)
    }
    const onGenderChange=(event)=>{
        setGender(event.target.value)
    }
    const onAgeChange=(event)=>{
        setAge(event.target.value)
    }
    const onSalaryChange=(event)=>{
        setSalary(event.target.value)
    }

    const onUpdate=async (event)=>{
        event.preventDefault();
        const employee={
            id:id*1,
            name,
            gender,
            age:age*1,
            salary:salary*1
            
        }
        await updateEmployee(employee);
        navigate("/")
    }

    return(
        <div className="container">
            <h3 className="text-primary">Update Employee</h3>
            <form className="col-4" onSubmit={onUpdate}>
                <div className="form-group">
                    <label>Employee Id</label>
                    <input type="text" className="form-control" onChange={onIdChange} value={id} readOnly />
                </div>
                <div className="form-group">
                    <label>Name</label>
                    <input type="text" className="form-control" onChange={onNameChange} value={name}/>
                </div>
                <div className="form-group">
                    <label>Gender</label>
                    &nbsp;
                    <div className="form-check-inline">
                        <input type="radio" name="gender" value="Male" className="form-check-input"
                        onChange={onGenderChange} checked={gender==='Male'}/>
                        <label className="form-check-label">Male</label>
                    </div>
                    &nbsp;
                    <div className="form-check-inline">
                        <input type="radio" name="gender" value="Female" className="form-check-input"
                        onChange={onGenderChange} checked={gender==='Female'}
                        />
                        <label className="form-check-label">Female</label>
                    </div>
                </div>
                <div className="form-group">
                    <label>Age</label>
                    <input type="text" className="form-control" onChange={onAgeChange} value={age} />
                </div>
                <div className="form-group">
                    <label>Salary</label>
                    <input type="text" className="form-control" onChange={onSalaryChange} value={salary}/>
                </div>
                <br/>
                <button className="btn btn-primary">Add Employee</button>
            </form>
        </div>
    )
}

export default UpdateEmployee;