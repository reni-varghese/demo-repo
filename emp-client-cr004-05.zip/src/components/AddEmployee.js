import { useState } from "react";
import { addEmployee } from "../services/apiCalls";
import {useNavigate, userNavigate} from 'react-router-dom';

const AddEmployee=()=>{

    const [id,setId]=useState('');
    const [name,setName]=useState('');
    const [gender,setGender]=useState('');
    const [age,setAge]=useState('')
    const [salary,setSalary]=useState('')

    const navigate=useNavigate();
    const onIdChange=(event)=>{
        setId(event.target.value)
    }
    const onNameChange=(event)=>{
        setName(event.target.value)
    }
    const onGenderChange=(event)=>{
        setGender(event.target.value)
    }
    const onAgeChange=(event)=>{
        setAge(event.target.value)
    }
    const onSalaryChange=(event)=>{
        setSalary(event.target.value)
    }

    const onAdd=async (event)=>{
        event.preventDefault();
        const employee={
            id:id*1,
            name,
            gender,
            age:age*1,
            salary:salary*1
            
        }
        await addEmployee(employee);
        navigate("/")
    }

    return(
        <div className="container">
            <h3 className="text-primary">Add Employee</h3>
            <form className="col-4" onSubmit={onAdd}>
                <div className="form-group">
                    <label>Employee Id</label>
                    <input type="text" className="form-control" onChange={onIdChange}/>
                </div>
                <div className="form-group">
                    <label>Name</label>
                    <input type="text" className="form-control" onChange={onNameChange}/>
                </div>
                <div className="form-group">
                    <label>Gender</label>
                    &nbsp;
                    <div className="form-check-inline">
                        <input type="radio" name="gender" value="Male" className="form-check-input"
                        onChange={onGenderChange}/>
                        <label className="form-check-label">Male</label>
                    </div>
                    &nbsp;
                    <div className="form-check-inline">
                        <input type="radio" name="gender" value="Female" className="form-check-input"
                        onChange={onGenderChange}
                        />
                        <label className="form-check-label">Female</label>
                    </div>
                </div>
                <div className="form-group">
                    <label>Age</label>
                    <input type="text" className="form-control" onChange={onAgeChange}/>
                </div>
                <div className="form-group">
                    <label>Salary</label>
                    <input type="text" className="form-control" onChange={onSalaryChange}/>
                </div>
                <br/>
                <button className="btn btn-primary">Add Employee</button>
            </form>
        </div>
    )
}

export default AddEmployee;