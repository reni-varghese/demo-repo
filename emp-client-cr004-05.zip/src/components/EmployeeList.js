import { useEffect, useState } from "react"
import { getAll } from "../services/apiCalls"

const EmployeeList=()=>{
    const [employees,setEmployees]=useState([]);
    useEffect(()=>{
        return async ()=>{
            const employeeList=await getAll();
            
            setEmployees(employeeList);
        }
    },[])
    return(
        <div className="container">
            <h3 className="text-primary">Employee Details</h3>
            <table className="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Employee Id</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Age</th>
                        <th>Salary</th>
                        <th>Operations</th>
                    </tr>
                </thead>
                <tbody>
                    {employees.map(emp=><tr key={emp.id}>
                        <td>{emp.id}</td>
                        <td>{emp.name}</td>
                        <td>{emp.gender}</td>
                        <td>{emp.age}</td>
                        <td>{emp.salary}</td>
                        <td>
                            <a className="btn btn-outline-warning" href={`/update/${emp.id}`}>Update</a>
                            &nbsp;&nbsp;
                            <a className="btn btn-outline-danger" href={`/delete/${emp.id}`}>Delete</a>
                        </td>
                    </tr>)}
                </tbody>
            </table>
        </div>
    )
}

export default EmployeeList;