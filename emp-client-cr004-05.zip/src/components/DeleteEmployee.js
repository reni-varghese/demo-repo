import { useEffect, useRef, useState } from "react"
import { useParams,useNavigate } from "react-router-dom";
import { deleteEmployee, getById } from "../services/apiCalls";

const DeleteEmployee=()=>{
    const [employee,setEmployee]=useState({});
    const params=useParams();
    const flag=useRef(true);
    useEffect(()=>{
        if(flag.current){
        return async ()=>{
            flag.current=false;
            const data=await getById(+params.id);
            setEmployee(data);
        }
    }
    })
    const navigate=useNavigate();
    const onCancel=()=>{
        navigate("/")
    }
    const onDelete=async ()=>{
        await deleteEmployee(+params.id);
        navigate("/")
    }

    return(
        <div className="container">
            <h3 className="text-danger">Do you wish to delete Employee {employee.name}?</h3>
            <table className="table table-striped table-borderd">
                <tbody>
                    <tr>
                        <td>Employee id</td>
                        <td>{employee.id}</td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td>{employee.name}</td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td>{employee.gender}</td>
                    </tr>
                    <tr>
                        <td>Age</td>
                        <td>{employee.age}</td>
                    </tr>
                    <tr>
                        <td>Salary</td>
                        <td>{employee.salary}</td>
                    </tr>
                </tbody>
            </table>
            <button className="btn btn-success" onClick={onCancel}>Cancel</button>
            &nbsp;&nbsp;
            <button className="btn btn-danger" onClick={onDelete}>Delete</button>
        </div>
    )
}

export default DeleteEmployee;