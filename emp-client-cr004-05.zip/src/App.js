import { createBrowserRouter,RouterProvider } from 'react-router-dom';
import EmployeeList from './components/EmployeeList';
import 'bootstrap/dist/css/bootstrap.min.css'
import './components/styles.css'
import AddEmployee from './components/AddEmployee';
import RootLayout from './components/RootLayout';
import UpdateEmployee from './components/UpdateEmployee';
import DeleteEmployee from './components/DeleteEmployee';


const router=createBrowserRouter([
  {path:"/", element:<RootLayout/>,
    children:[
      {path:"/",element:<EmployeeList/>},
      {path:"/add",element:<AddEmployee/>},
      {path:"/update/:id",element:<UpdateEmployee/>},
      {path:"/delete/:id",element:<DeleteEmployee/>}
    ]

}
  
])

function App() {
  return (
    <div>
     <RouterProvider router={router}/>
    </div>
  );
}

export default App;
