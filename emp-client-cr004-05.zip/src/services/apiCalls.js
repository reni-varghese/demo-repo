import axios from "axios";
const getAll=async ()=>{
    const response=await axios.get("http://localhost:5000/api/employees");
    return response.data;
}

const addEmployee= async(employee)=>{
    return await axios.post("http://localhost:5000/api/employees",employee)
}

const getById=async (id)=>{
    const response=await axios.get(`http://localhost:5000/api/employees/${id}`)
    return response.data;
}

const updateEmployee=async (employee)=>{
    return await axios.put(`http://localhost:5000/api/employees/${employee.id}`,employee)
}

const deleteEmployee=async (id)=>{
    return await axios.delete(`http://localhost:5000/api/employees/${id}`)
}


export {getAll,addEmployee,getById,updateEmployee,deleteEmployee};