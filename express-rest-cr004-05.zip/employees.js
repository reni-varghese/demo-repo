const employees=[
    {
        "id": 1,
        "name": "Manu",
        "gender": "Male",
        "age": 23,
        "salary": 77000.0
    },
    {
        "id": 2,
        "name": "Kiran",
        "gender": "Male",
        "age": 18,
        "salary": 67000.0
    },
    {
        "id": 3,
        "name": "Anu ",
        "gender": "Female",
        "age": 22,
        "salary": 88000.0
    },
    {
        "id": 4,
        "name": "Akshay",
        "gender": "Male",
        "age": 23,
        "salary": 45000.0
    },
    {
        "id": 6,
        "name": "Charu",
        "gender": "Female",
        "age": 20,
        "salary": 67000.0
    }
]

module.exports=employees;