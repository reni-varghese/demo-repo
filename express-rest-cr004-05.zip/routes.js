const express=require('express');
const employees=require('./employees');

const router=express.Router();

router.get("/api/employees",(req,res)=>{
    res.json(employees)
})

router.get("/api/employees/:id",(req,res)=>{
    
    const employee=employees.find(emp=>emp.id===+req.params.id);
    if(!employee){
        res.status(404).send({message:`Employee with Id ${req.params.id} does not exist`})
    }
    
    res.send(employee);
});

router.post("/api/employees",(req,res)=>{
    const employee=req.body;
    employees.push(employee);
    res.status(201).json({message:`Employee with id ${employee.id} added successfully`})
})

router.put("/api/employees/:id",(req,res)=>{
    const employee=req.body;
    const emp=employees.find(emp=>emp.id===+req.params.id);
    if(!emp){
        return res.status(404).send({message:`Employee with id ${req.params.id} does not exist`});
    }
    if(employee.name){
        emp.name=employee.name
    }
    if(employee.gender){
        emp.name=employee.name
    }
    if(employee.age){
        emp.age=employee.age;
    }
    if(employee.salary){
        emp.salary=employee.salary;
    }

    res.send({message:`Employee with id ${req.params.id} updated successfully`})

})

router.delete("/api/employees/:id",(req,res)=>{
    const employee=employees.find(emp=>emp.id===+req.params.id);
    if(!employee){
        return res.status(404).send({message:`Employee with id ${req.params.id} does not exist`});
    }
    const index=employees.indexOf(employee);
    employees.splice(index,1);
    res.send({message:`Employee with id ${req.params.id} deleted successfully`})


})

module.exports=router;