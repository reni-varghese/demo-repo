const Employee=require('../models/Employee');

exports.getAll=async (req,res)=>{

    const employees=await Employee.find();
    res.send(employees);
}

exports.addEmployee=async (req,res)=>{
    const employee=new Employee(req.body);
    const result=await employee.save();
    res.status(201).send({message:"Employee Saved successfully"})

}