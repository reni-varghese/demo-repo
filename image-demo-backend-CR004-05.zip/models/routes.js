const express=require('express');
const { getAll, addEmployee } = require('../controllers/employeeController');

const router=express.Router();

router.get("/api/employee",getAll);
router.post("/api/employee",addEmployee);