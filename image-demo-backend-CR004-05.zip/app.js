const express=require('express');
const mongoose=require('mongoose');
const cors=require('cors')


const app=express();
app.use(cors())
app.use(express.json());



mongoose.connect("mongodb://127.0.0.1/demdb")
.then(result=>{
    console.log("Connected to MongoDb");
    app.listen(5000,()=>{
        console.log("Server Listening @ PORT 5000")
    })
})